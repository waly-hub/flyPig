<template>
	<view>
		<view class="myhome">
			<!-- 已登录 -->
			<!-- <block v-for="(item,index) in username" :key="index"> -->
			<view class="wx-name" v-if="wxlogin">
				<view>
					<image :src="username.avatarUrl"></image>	
				</view>
				<view class="wx-text">
					<text>{{username.nickName}}</text>
				</view>
			</view>
			<!-- </block> -->
			<!-- 未登录 -->
			<view class="wx-button" v-if="!wxlogin">
				<view class="wx-button-view">登录生如夏花，开启旅程</view>
				<view>
					<button plain="true" open-type="getUserInfo" @getuserinfo="getUserInfo">去登录</button>
				</view>
			</view>
		</view>
		
		<!-- 列表 -->
		<view class="user-list" v-if="wxlogin">
			<block v-for="(item,index) in busindata" :key="index">
			<view @click="auTH(item.url)">
				<image :src="item.image" mode="widthFix"></image>
				<text>{{item.name}}</text>
			</view>
			</block>
		</view>
		
		<!-- 感谢 -->
		<view class="Thankyou">
			<text>全栈开发者，大数据开发者，腾讯课堂，爱奇艺，CSDN讲师</text>
			<text>学习前端开发，请上腾讯课堂搜索"全栈开发者阿耿"</text>
			<text>老师微信: TYLZ1125</text>
			<text>感谢百度AI，感谢腾讯云</text>
		</view>
	</view>
</template>

<script>
	import {login} from '../../common/list.js'
	var db = wx.cloud.database()
	var users = db.collection('user')
	export default{
		name:'my',
		data() {
			return {
				wxlogin: true,
				username:{},
				busindata:[
					{
						"image":"../../static/mys/gouwuche.svg",
						"name":"购物车",
						"url":"../MyCart/mycart"
					},
					{
						"image":"../../static/mys/dingdan.svg",
						"name":"我的订单",
						"url":"../Myorder/myorder"
					},
					{
						"image":"../../static/mys/kecheng.svg",
						"name":"老师课程",
						"url":"../course/course"
					},
					{
						"image":"../../static/mys/shuangshiyi.svg",
						"name":"双十一",
						"url":""
					}
				]
			}
		},
		methods:{
			// 发起登录
			getUserInfo(event){
				console.log(event)
				const user = event.detail.userInfo
				login(user)
				.then((res)=>{
					console.log(res)
					this.ifUser()
				})
				.catch((err)=>{
					console.log(err)
				})
			},
			
			// 用户是否登录
			ifUser(){
				users.get()
				.then((res)=>{
					console.log(res)
					// length == 0说明没有用户信息，没有登录，发起登录
					if(res.data.length == 0){
						this.wxlogin = false
						console.log('没有登录')
					}else{
						this.wxlogin = true
						console.log('已经登录')
						console.log(res)
						this.username = res.data[0]
					}
				})
				.catch((err)=>{
					console.log(err)
				})
			},
			
			// 跳转
			auTH(url){
				uni.navigateTo({
					url: url,
				});
			}
			
		},
		onShow() {
			// 请求用户信息数据库看看有没有存在用户信息
			this.ifUser()
		},
		onShareAppMessage(res) {
		    return {
		      title: '去旅游，上生如夏花旅途小程序',
		      path: '/pages/index/index'
		    }
		  },
	}
</script>

<style scoped>
	.myhome{background: linear-gradient(to top, #ffe566 10%, #ffd300 100%); height: 350upx; display: flex; align-items: center;}
	.wx-name image{width: 120upx !important; height: 120upx !important; border-radius: 50%; margin-right: 20upx;
					border: 10rpx solid #999999;}
	text{display: block; margin: 10upx 0; color: #999999;}
	.wx-name{display: flex; align-items: center; padding: 0 30upx; align-content: center;
			height: 200upx;}
	.wx-text text:nth-child(1){font-size: 35upx;}
	.wx-text text:nth-child(2){font-size: 20upx; border: 1px solid #FFFFFF;
								padding: 7upx;
								border-radius: 50upx;
								text-align: center;}
	/* 登录 */
	.wx-button button{border: none;font-size: 30upx; background: linear-gradient(to right, #28a6f1 10%, #0e8dd7 80%);
	 border-radius: 50upx;
	color: #FFFFFF;}							
	.wx-button-view{font-size: 35upx; color: #FFFFFF; margin-bottom: 25upx;}
	.wx-button{margin: 0 auto;}
	/* 列表 */
	.user-list{background: #F8F8F8; display: flex; justify-content: space-around; text-align: center;
	margin: 20upx; border-radius: 20upx;
	height: 200upx;
	align-items: center;}
	.user-list image{width: 50upx; height: 50upx;}
	.user-list text{font-size: 25upx; display: block; color: #777777;}
	/* 感谢 */
	.Thankyou{font-size: 20upx; text-align: center;
	position: fixed;
	left: 0;
	right: 0;
	bottom: 30upx;}
</style>
