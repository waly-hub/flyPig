<template>
	<view class="kecheng-view">
		<view class="kecheng-tips">
			uni-app开发仿阿里飞猪旅游课程补录公告
		</view>
		
		<view class="kecheng-title marginview">《一》自从uniapp课程上架以来广受各位开发者的喜爱，同时也接收到很多开发者的建议，为此在之前的课程上对该门课程
		再次补录新功能，主要补录在微信支付方面，目前已上架到小程序可到产品中体验功能，具体补录如下:
		</view>
		<view class="kecheng-lile marginview">
			<block v-for="(item,index) in kecheng" :key="index">
			<text>{{item}}</text>
			</block>
		</view>
		
		<view class="kecheng-title marginview">《二》新补录的课程上架之前价格不变(补录之前的价格：178元)，新补录的课程上架之后价格会上调，补录之前已购买的用户不受任何影响
		</view>
		
		<view class="kecheng-title marginview">
		《三》该门课程上架到腾讯课堂，爱奇艺，csdn，网易云课堂平台，除腾讯课堂外其他平台无法上传课程源码，课程图标等资料，遇到问题也很难
		联系到老师，鉴于此种情况，建议各位到《腾讯课堂》购买观看，腾讯课堂提供课程所有资料，源码下载，也很方便在线联系到老师，
		腾讯课堂搜索"全栈开发者阿耿"，便是老师的课程。另外请勿在苹果手机上购买课程，可使用安卓手机或在电脑端购买
		</view>
		
		<view class="kecheng-title marginview" @click="fuzhi">
		《四》联系老师微信: TYLZ1125 (点击复制微信号)  加入微信学习群
		</view>
		
	</view>
</template>

<script>
	export default{
		data() {
			return {
				kecheng:[
					'1.新增商家端小程序,商家可发布商品到C端，用户购买',
					'2.首页tab切换的详情页新增加入购物车和下单功能',
					'3.新增购物车页面，用户可添加商品到购物车',
					'4.用户可直接下单购买',
					'5.用户可从购物车下单发起微信支付购买',
					'6.用户购买成功可查看自己的订单'
				]
			}
		},
		
		methods:{
			fuzhi(){
				wx.setClipboardData({
					data:'TYLZ1125',
					success: (res) => {
						wx.getClipboardData({
							success: (res) => {
								wx.showToast({
								  title: '复制成功'
								})
							}
						})
					}
				})
			}
		}
	}
</script>

<style scoped>
	.kecheng-view{padding: 15upx;}
	.kecheng-tips{font-size: 30upx; font-weight: bold; padding: 30upx 0; text-align: center;}
	.marginview{margin-bottom: 40upx;}
	.kecheng-title{font-size: 28upx; line-height: 1.7;}
	.kecheng-lile text{display: block; font-size: 28upx; line-height: 1.7;}
</style>
