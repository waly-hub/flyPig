<template>
	<view>
		<view class="locality">
			<view class="title">当地必体验</view>
		</view>	
		<!-- tab -->
		<view class="menu-block">
			<block v-for="(item,index) in citytab" :key="index">
				<view :class="{ activetext: index == num }" @click="menubtn(index,item.name)">{{item.name}}</view>
			</block>
		</view>
		
	</view>
</template>

<script>
	export default{
		name:'locality',
		data() {
			return {
				num:0,
				citytab: [
					{
						"name":'全部'
					},
					{
						"name":'景点'
					},
					{
						"name":'美食'
					},
					{
						"name":'网红打卡'
					}
				],
				Article:[
					{
						"image":"https://img.alicdn.com/bao/uploaded/i2/3332178643/O1CN012tAZ532DiXkITtKfW_!!3332178643.jpg_400x400.jpg",
						"name":"昆明三日游",
						"title":"[天晴姐步履不停之]扑棱扑棱，心中飞出一千只海鸥"
					},
					{
						"image":"https://img.alicdn.com/bao/uploaded/i1/1720163045/O1CN010geuBg1YMeX8sVYr5_!!1720163045.jpg_400x400.jpg",
						"name":"春节在春城过春天",
						"title":"根据年度旅游大数据，对我来说，这个答案只能是——昆明 刚刚，就在动笔写这篇游记的前一天，再度四过昆明刚刚",
					},
					{
						"image":"https://img.alicdn.com/bao/uploaded/i2/3230851713/O1CN01vSj93b1OWawxMZnMT_!!3230851713.jpg_400x400.jpg",
						"name":"滇池与西山一日游",
						"title":"昆明原本是1座重要的旅游城市，但近年来似乎沦为了前往云南各地的中转站",
					},
					{
						"image":"https://img.alicdn.com/bao/uploaded/i1/2939694477/O1CN01CLHa2X1iwVjDjIRVU_!!2939694477.jpg_400x400.jpg",
						"name":"唐山跟团游",
						"title":"大理环洱海包车一日游双廊喜洲沙溪代订包车",
					},
					{
						"image":"https://img.alicdn.com/bao/uploaded/i4/488718576/O1CN017YHEWx2DDrAsZqAqO_!!488718576.jpg_400x400.jpg",
						"name":"唐山跟团游",
						"title":"四川成都旅游  色达旅游 拼车4天3晚 拼车 自由行",
					},
					{
						"image":"https://img.alicdn.com/bao/uploaded/i1/3602861595/O1CN01A4oN8S1NeYFb27Iaz_!!3602861595.jpg_400x400.jpg",
						"name":"唐山跟团游",
						"title":"四川成都到冶勒湖孟获城纯玩两日游成都周边2天1晚游草甸古城湖泊",
					},
					{
						"image":"https://img.alicdn.com/bao/uploaded/i3/3934000375/O1CN01c09KQ91Edn2Ui3jXA_!!3934000375.jpg_400x400.jpg",
						"name":"唐山跟团游",
						"title":"云南丽江包车旅游到玉龙雪山泸沽湖大理香格里拉亚丁梅里代订包车",
					}
				]
			}
		},
		
		methods:{
			menubtn(index,name){
				this.num = index
				console.log(name)
				// 查询数据库
				// const db = wx.cloud.database()
				// const listdata = db.collection('userdata')
				// 如果点了全部则不做筛选
				// 子组件调用父组件方法
				this.$parent.fatherMethod(name);
				// if(name == '全部'){
				// 	console.log('全部')
				// }else{
				// 	listdata.where({
				// 	  datainfo:{
				// 		  classdata:name
				// 	  }
				// 	})
				// 	.get()
				// 	.then((res)=>{
				// 		console.log(res)
				// 	})
				// 	.catch((err)=>{
				// 		console.log(err)
				// 	})
				// }
				
			},
		}
		
	}
</script>

<style scoped>
	.locality{margin: 0 20upx;}
	.title{color: #292c33; font-size: 50upx;}
	.activetext{color: #4CD964; background: #ffdd00 !important; border: 1px solid #ffdd00 !important;}
	.menu-block view {
		background: #ffffff;
		border: 1px solid #c2c5cc;
		border-radius: 6upx;
		font-size: 25upx;
		color: #292c33;
		font-weight: bold;
		text-align: center;
		padding: 15upx;
		margin: 20upx;
	}
	
	.menu-block {
		display: flex;
		flex-direction: row;
		justify-content: flex-start;
		flex-wrap: wrap;
	}
</style>
