<template>
	<view class="course-list">
		<view class="xuexi">学习以下课程请到腾讯课堂搜索“全栈开发者阿耿”</view>
		<block v-for="(item,index) in kecheng" :key="index">
		<view class="course-view">
			<view>
				<image :src="item.image" mode="widthFix"></image>
			</view>
			<view class="course-title">{{item.title}}</view>
		</view>
		</block>
	</view>
</template>

<script>
	export default{
		data() {
			return {
				kecheng: [
					{
						"id":0,
						"image":"../../static/teach/teg.png",
						"title":"uniapp入门到实战，vue中高级课程"
					},
					{
						"id":1,
						"image":"../../static/teach/tea.jpg",
						"title":"微信小程序零基础到实战，仿腾讯视频"
					},
					{
						"id":2,
						"image":"../../static/teach/teb.jpg",
						"title":"vue零基础入门到实战"
					},
					{
						"id":3,
						"image":"../../static/teach/tec.jpg",
						"title":"小程序云开发拍照识花"
					},
					{
						"id":4,
						"image":"../../static/teach/ted.jpg",
						"title":"小程序人脸识别"
					},
					{
						"id":5,
						"image":"../../static/teach/tee.jpg",
						"title":"小程序识图取字"
					},
					{
						"id":6,
						"image":"../../static/teach/tef.jpg",
						"title":"小程序云开发人脸融合"
					}
				]
			}
		},
	}
</script>

<style scoped>
	.course-list{padding: 20upx;}
	.xuexi{padding: 40upx 0; font-size: 35upx; font-weight: bold;}
	.course-view image{width: 100%; border-radius: 16upx;}
	.course-view{position: relative; margin-bottom: 20upx;}
	.course-title{position: absolute; top: 10upx; left: 10upx; color: #FFFFFF; font-size: 30upx;}
</style>
